<template>
  <router-view></router-view>
</template>
<script setup lang="ts">
</script>
<style>
#app {
  height: 100%;
  text-align: center;
  color: var(--el-text-color-primary);
  background: var(--el-bg-color);
}

.element-plus-logo {
  width: 50%;
}
</style>