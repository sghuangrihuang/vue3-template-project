<script setup lang="ts">
import Layout from "./../../components/layout.vue";
</script>

<template>
  <Layout>
    <div class="">chatgpt</div>
  </Layout>
</template>

<style scoped lang="scss">

</style>