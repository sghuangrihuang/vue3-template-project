<script setup lang="ts">
import Layout from "./../../components/layout.vue";
</script>

<template>
  <Layout>
    <div class="">other</div>
  </Layout>
</template>

<style scoped lang="scss">

</style>