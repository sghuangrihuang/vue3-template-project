<!--
 * @Date: 2023-03-01 15:43:25
 * @LastEditors: Yaowen Liu
 * @LastEditTime: 2023-04-10 12:45:03
 * @FilePath: /vue3-waterfall/example/components/WaterfallList.vue
-->
<template>
  <img src="https://img.yzcdn.cn/vant/logo.png">
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>